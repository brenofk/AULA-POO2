package Segunda_Atividade;

public class Data extends Tempo {

	private int dia, mes, ano;
	
	public Data() {
		this.dia = 1;
		this.mes = 1;
		this.ano = 2020;
	}
	
	public Data(int dia, int mes, int ano) {
		this.dia = dia;
		this.mes = mes;
		this.ano = ano;
	}
	
	public void setDia(int dia) {
		this.dia = dia;
	}
	public int getDia() {
		return this.dia;
	}
	
	public void setMes(int mes) {
		this.mes = mes;
	}
	public int getMes() {
		return this.mes;
	}
	
	public void setAno(int ano) {
		this.ano = ano;
	}
	public int getAno() {
		return this.ano;
	}
	
	@Override
	public long quantidade() {
		// 
		return (ano * 31104000) + (mes * 2592000) + (dia * 86400);
	}
	@Override 
	public String toString () {
		return dia + "/" + mes + "/" + ano;
	}
	
}
