package Segunda_Atividade;

public class Horario extends Tempo {

	private int horas, minutos, segundos;	
	
	
	public Horario() {
		this.horas = 0;
		this.minutos = 0;
		this.segundos = 0;
	}
	
	public Horario(int horas, int minutos, int segundos) {
		this.horas = horas;
		this.minutos = minutos;
		this.segundos = segundos;
	}
	
	public void setHoras(int horas) {
		this.horas = horas;
	}
	public int getHoras() {
		return this.horas;
	}
	
	public void setMinutos(int minutos) {
		this.minutos = minutos;
	}
	public int getMinutos() {
		return this.minutos;
	}
	
	public void setSegundos(int segundos) {
		this.segundos = segundos;
	}
	public int getSegundos() {
		return this.segundos;
	}
	
	
	@Override
	public long quantidade() {
		return (horas * 3600) + (minutos * 60) + segundos;
	}
	
	@Override
	public String toString() {
		return horas + ":" + minutos + ":" + segundos;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
