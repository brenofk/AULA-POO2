package Segunda_Atividade;

public class TestaDia {

	public static void main(String[] args) {

		Data data1 = new Data(15, 8 ,2024);
		
		System.out.println("Data 1:");
		System.out.println("Dia: " + data1.getDia());
		System.out.println("Mes " + data1.getMes());
		System.out.println("Ano: " + data1.getAno());
		System.out.println("Data Formatada: " + data1.toString());
		System.out.println("Quantidade em segundos: " + data1.quantidade());
		
		Data data2 = new Data();
		
		System.out.println("\nData 2:");
		System.out.println("Dia: " + data2.getDia());
		System.out.println("Mes " + data2.getMes());
		System.out.println("Ano: " + data2.getAno());
		System.out.println("Data Formatada: " + data2.toString());
		System.out.println("Quantidade em segundos: " + data2.quantidade());
		

		data2.setDia(1);
		data2.setMes(1);
		data2.setAno(1970);
		

		System.out.println("\nData 2: (alterad) ");
		System.out.println("Dia: " + data2.getDia());
		System.out.println("Mes " + data2.getMes());
		System.out.println("Ano: " + data2.getAno());
		System.out.println("Data Formatada: " + data2.toString());
		System.out.println("Quantidade em segundos: " + data2.quantidade());
	}

}
