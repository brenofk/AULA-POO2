package Segunda_Atividade;

public class TestaHorario {
	
    public static void main(String[] args) {
    	
        try {
         
            Horario horario1 = new Horario();
            System.out.println("construtor sem parâmetros:");
            exibirHorario(horario1);

    
            Horario horario2 = new Horario(10, 30, 45);
            System.out.println("\nHorario 2 (construtor com parâmetros 10, 30, 45):");
            exibirHorario(horario2);

   
            horario1.setHoras(8);
            horario1.setMinutos(15);
            horario1.setSegundos(20);
            System.out.println("\nHorario 1 após usar métodos set (8, 15, 20):");
            System.out.println("Hora: " + horario1.getHoras());
            System.out.println("Minutos: " + horario1.getMinutos());
            System.out.println("Segundos: " + horario1.getSegundos());
            exibirHorario(horario1);

            System.out.println("\nQuantidade de segundos no Horario 2: " + horario2.quantidade());

            System.out.println("\nTestando validação com valores inválidos:");
            Horario horarioInvalido = new Horario(25, 61, 61); 
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    private static void exibirHorario(Horario horario) {
        System.out.println("Horario formatado: " + horario.toString());
        System.out.println("Tempo em segundos: " + horario.quantidade());
    }
}
