package Segundo_Bimestre;

public class TestaBrinquedo {

	public static void main(String[] args) {

		Brinquedo brinquedo1 = new Brinquedo();
		brinquedo1.mostrar();
		
		System.out.println("");
		
		Brinquedo brinquedo2 = new Brinquedo("Carrinho");
		brinquedo2.setFaixaEtaria("3 a 5");
		brinquedo2.setPreco(29.99f);
		brinquedo2.mostrar();
		
		System.out.println("");

		Brinquedo brinquedo3 = new Brinquedo("Boneca", 49.99f);
		brinquedo3.setFaixaEtaria("6 a 10");
		brinquedo3.mostrar();
		
		System.out.println("");

		try {
			brinquedo3.setFaixaEtaria("13 a 15");
		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
		
		brinquedo1.setNome("Jogo Educativo");
		brinquedo1.setPreco(59.99f);
		brinquedo1.setFaixaEtaria("acima de 10");
		brinquedo1.mostrar();
		
	}
}
